
export default function Register(){
  return(
    <div>
      <h1>Pagina Register</h1>
    </div>
  )
}